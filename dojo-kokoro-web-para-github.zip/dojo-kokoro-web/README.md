# Dojo Kokoro · Karate-Do Shotokan

Sitio web oficial de **Dojo Kokoro Karate-Do Shotokan**, Santa Bárbara de Heredia, Costa Rica. Clases para niños, jóvenes y adultos; **primera clase gratis**.

Es un sitio estático de tres páginas, sin dependencias, sin base de datos y sin cuentas de usuario. El contacto se hace por **WhatsApp**.

> **Dirección del sitio:** <https://tonyruizg.github.io/dojo-kokoro-web/> · **Repositorio:** <https://github.com/TonyRuizG/dojo-kokoro-web>

| Página | Ruta | Para qué sirve |
|---|---|---|
| Inicio | `/` | Presentar la filosofía, los horarios y la ubicación, y convertir visitantes en alumnos con un formulario que continúa por WhatsApp. |
| Nuestro dojo | `/nuestro-dojo/` | Identidad, Dojo Kun, senseis, metodología, trayectoria deportiva, respaldo institucional y galería. |
| Programa educativo | `/programa-educativo/` | Propuesta de karate-do extracurricular para escuelas, colegios e instituciones. |

## Contenido

- [Características](#características)
- [Estructura del proyecto](#estructura-del-proyecto)
- [Ejecutarlo en tu computadora](#ejecutarlo-en-tu-computadora)
- [Cómo cambiar el contenido](#cómo-cambiar-el-contenido)
- [Publicar en GitHub Pages](#publicar-en-github-pages)
- [Dominio propio](#dominio-propio)
- [Otros hostings](#otros-hostings)
- [Calidad, accesibilidad y SEO](#calidad-accesibilidad-y-seo)
- [Derechos](#derechos)

## Características

- **Tres páginas** con encabezado y pie compartidos, barra lateral flotante por secciones y transición suave entre páginas (respeta `prefers-reduced-motion`).
- **Formulario de primera clase:** la persona escribe el nombre de quien va a entrenar y su edad, y *Continuar por WhatsApp* abre la conversación con el mensaje ya redactado. No se guarda ningún dato.
- **Ubicación** con enlaces a Google Maps y Waze y mapa de Waze incrustado.
- **SEO** por página: título, descripción, URL canónica, Open Graph, Twitter Card, datos estructurados (schema.org), `sitemap.xml` y `robots.txt`.
- **Rutas relativas:** funciona igual en un dominio propio o en una carpeta como `/dojo-kokoro-web/`.
- **Rápido y liviano:** HTML, CSS y JavaScript simples; imágenes WebP optimizadas; menos de 1 MB por página.
- **Sin dependencias:** no hay `npm install`. Un generador de un solo archivo (`build.mjs`) arma las páginas.
- **Publicación automática:** cada cambio en la rama `main` se publica solo con GitHub Actions.

## Estructura del proyecto

```
dojo-kokoro-web/
├── .github/workflows/deploy.yml   Publicación automática en GitHub Pages
├── build.mjs                      Generador del sitio (Node 18 o superior, sin dependencias)
├── package.json                   Atajos: npm run build / start / revisar
├── vercel.json · netlify.toml     Configuración opcional para Vercel o Netlify
├── src/                           ← AQUÍ SE EDITA TODO
│   ├── site.json                  Teléfono, redes, mapas, mensajes de WhatsApp, avisos «Pendiente»
│   ├── layout.html                Estructura común de las páginas (<head>, SEO, Open Graph)
│   ├── pages/                     Una plantilla por página (index, nuestro-dojo, programa-educativo, 404)
│   ├── partials/                  Componentes reutilizables (encabezado, pie, portada, etc.)
│   ├── css/                       Estilos organizados por tema; se unen en un solo archivo
│   ├── js/site.js                 Menú, barra lateral, formulario de WhatsApp y transición entre páginas
│   ├── data/                      galeria.json y logros.json
│   ├── assets/                    Imágenes e íconos
│   └── static/                    Favicon y archivos que se copian a la raíz
├── tools/
│   ├── revisar-sitio.mjs          Revisión automática (enlaces, SEO, WhatsApp, mapa, formulario)
│   ├── servir.mjs                 Servidor local con URLs limpias
│   └── optimizar-imagenes.py      (opcional) Prepara fotos para la galería
└── docs/
    ├── CAMBIOS.md                 Qué cambió respecto a la versión original
    └── PENDIENTES.md              Datos y fotos por confirmar
```

`dist/` y `dist-local/` se generan con `node build.mjs`; no se editan a mano ni se suben al repositorio.

## Ejecutarlo en tu computadora

Necesitas [Node.js](https://nodejs.org) 18 o superior (solo para generar el sitio).

```bash
git clone https://github.com/TonyRuizG/dojo-kokoro-web.git
cd dojo-kokoro-web

node build.mjs                 # genera dist/
node tools/servir.mjs dist     # abre http://localhost:8080
```

También: `npm start`. Si prefieres no usar un servidor, `node build.mjs --local` genera `dist-local/`, cuyo `index.html` se abre con doble clic.

Cada vez que cambies algo en `src/`, vuelve a ejecutar `node build.mjs`.

### Revisión automática

```bash
node build.mjs && node tools/revisar-sitio.mjs dist
```

Comprueba enlaces e imágenes, anclas, números y mensajes de WhatsApp, enlaces de Maps y Waze, el formulario, metadatos SEO, un único `<h1>` por página, textos alternativos y que no quede ninguna fecha de lanzamiento. Termina con error si algo falla, y el flujo de publicación lo ejecuta antes de cada despliegue.

## Cómo cambiar el contenido

| Quiero cambiar… | Dónde |
|---|---|
| Teléfono, Instagram, Facebook | `src/site.json` |
| Enlaces de Google Maps, Waze y mapa incrustado | `src/site.json` → `maps`, `waze`, `wazeEmbed`, `geo` |
| Mensajes de WhatsApp de los botones | `src/site.json` → `wa` |
| Mensaje del formulario (usa `{nombre}` y `{edad}`) | `src/site.json` → `formulario.mensaje` |
| Horarios y grupos | `src/pages/index.html` (sección `#horarios`) |
| Textos de una página | `src/pages/*.html` |
| Encabezado, pie o menú | `src/partials/header.html`, `footer.html` |
| Colores y tipografías | `src/css/00-base.css` (variables al inicio) |
| Logros de los atletas | `src/data/logros.json` |
| Fotos de la galería | `src/data/galeria.json` y `src/assets/img/galeria/` |
| Título y descripción para buscadores | comentario `<!--page {...}-->` al inicio de cada archivo de `src/pages/` |

**Agregar fotos a la galería**

1. Copia las fotos reales del dojo a una carpeta y ejecuta `python3 tools/optimizar-imagenes.py CARPETA` (requiere Pillow). Las deja listas en `src/assets/img/galeria/` e imprime las entradas para el JSON.
2. Pega esas entradas en `src/data/galeria.json` y escribe un texto `alt` que describa cada foto.
3. Ejecuta `node build.mjs`. Se muestran 6 fotos y el resto queda en «Ver más fotos».

> Antes de publicar fotos de menores de edad, confirma la autorización de sus padres o encargados.

**Avisos «Pendiente».** Donde falta información confirmada, el sitio muestra un recuadro punteado «Pendiente» mientras trabajas en tu computadora. En la publicación de GitHub Pages **se ocultan solos**. Para verlos también allí: *Settings → Secrets and variables → Actions → Variables* y crea `SHOW_PENDING` con el valor `true`. La lista completa está en [`docs/PENDIENTES.md`](docs/PENDIENTES.md).

## Publicar en GitHub Pages

El flujo `.github/workflows/deploy.yml` genera el sitio y lo publica cada vez que se actualiza la rama `main`. Solo hay que preparar el repositorio una vez.

**1. Tener el repositorio.** En GitHub: *New repository* → nombre `dojo-kokoro-web` → **Public**. (Ya existe: `TonyRuizG/dojo-kokoro-web`. Da igual si lo creaste vacío o con el README inicial que ofrece GitHub.)

**2. Subir el proyecto.** Clona el repositorio, copia dentro los archivos del proyecto (reemplazando el `README.md` y el `.gitignore` iniciales) y súbelo:

```bash
git clone https://github.com/TonyRuizG/dojo-kokoro-web.git
# copia aquí los archivos del proyecto
cd dojo-kokoro-web
git add .
git commit -m "Sitio web de Dojo Kokoro"
git branch -M main
git push -u origin main
```

El `.gitignore` deja fuera `dist/`, `dist-local/` y `respaldo-original/` (el respaldo incluye la presentación comercial y no debe quedar público).

**3. Activar Pages.** En el repositorio: *Settings → Pages → Build and deployment → Source: **GitHub Actions***.

**4. Esperar la publicación.** En la pestaña *Actions* aparece «Publicar en GitHub Pages». Cuando termina en verde, el sitio queda en <https://tonyruizg.github.io/dojo-kokoro-web/>. Si el `push` se hizo antes de activar Pages, esa primera ejecución falla en rojo: es normal. Activa Pages y entra a *Actions → Publicar en GitHub Pages → Run workflow*.

**Desde entonces**, cada `git push` a `main` actualiza el sitio en uno o dos minutos.

### Cómo funcionan las rutas

El sitio vive en una carpeta (`/dojo-kokoro-web/`), no en la raíz del dominio. Por eso:

- Los enlaces, imágenes, CSS y JavaScript son **relativos**, y funcionan en cualquier carpeta.
- El flujo pasa la dirección real a `build.mjs` con `SITE_URL`, y de ahí salen las URL canónicas, Open Graph, `sitemap.xml` y `robots.txt`.
- La página `404.html` usa rutas absolutas dentro de esa carpeta, para verse bien aunque falle una URL profunda.

Para generar localmente una copia con la dirección de GitHub Pages:

```bash
SITE_URL=https://tonyruizg.github.io/dojo-kokoro-web node build.mjs
```

## Dominio propio

1. Compra el dominio y, en tu proveedor, apunta un registro `CNAME` (subdominio `www`) a `tonyruizg.github.io` (o los registros `A` que indica la [documentación de GitHub](https://docs.github.com/pages/configuring-a-custom-domain-for-your-github-pages-site)).
2. En *Settings → Pages → Custom domain* escribe el dominio y activa *Enforce HTTPS*.
3. Vuelve a ejecutar el flujo (*Actions → Run workflow*): las URL canónicas y el sitemap se actualizan solos con el dominio nuevo.

## Otros hostings

- **Netlify / Vercel:** importa el repositorio; `netlify.toml` y `vercel.json` ya configuran el comando (`node build.mjs`) y la carpeta (`dist`). Ambos exponen su dirección pública y el generador la usa sola.
- **Cualquier hosting estático:** ejecuta `node build.mjs` y sube el **contenido** de `dist/`.

## Calidad, accesibilidad y SEO

- HTML semántico, enlace «Saltar al contenido», navegación por teclado con foco visible, textos alternativos, formulario con etiquetas y mensajes de error asociados, kanji decorativos ocultos a lectores de pantalla (`aria-hidden`) y marcados con `lang="ja"`.
- Los colores de texto principales del diseño superan el contraste mínimo AA (4,5 : 1) sobre sus fondos.
- Respeta `prefers-reduced-motion`: sin animaciones ni transiciones de página para quien lo pide.
- Imágenes en WebP con tamaños declarados, carga diferida y `srcset` para las fotos de los senseis.
- Un título, una descripción, URL canónica, Open Graph y Twitter Card distintos por página.
- CSS y JavaScript en un solo archivo cada uno, con versión en la URL para que el navegador los actualice.
- Las tipografías (Oswald, DM Sans y Noto Serif JP, esta última solo con los kanji usados) se cargan desde Google Fonts.

## Derechos

© Dojo Kokoro Karate-Do Shotokan. Todos los derechos reservados.

El logo de Kokoro, las fotografías y los logos de ISKF Costa Rica y del CCDR de Santa Bárbara pertenecen a sus titulares. No se concede licencia para reutilizarlos. Si quieres que otras personas puedan reutilizar el **código**, agrega un archivo `LICENSE` (por ejemplo MIT) que cubra solo el código.
